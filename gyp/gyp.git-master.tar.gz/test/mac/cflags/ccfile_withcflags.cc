#ifndef CFLAG
#error CFLAG should be set
#endif

#ifndef CCFLAG
#error CCFLAG should be set
#endif
