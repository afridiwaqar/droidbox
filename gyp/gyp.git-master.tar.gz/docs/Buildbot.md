# Buildbot

Gyp's Buildbot status page can be found here:
http://build.chromium.org/f/client/gyp/

The code that implements Gyp's test waterfall is called "parasite" and is an
experimental replacement for Buildbot's build master that uses trybots to run
tests.  The code can be found here:
http://src.chromium.org/viewvc/chrome/trunk/tools/parasite/
