GYP can Generate Your Projects.

Mailing list:  http://groups.google.com/group/gyp-developer

* [User documentation](/docs/UserDocumentation.md)
* [Input Format Reference](/docs/InputFormatReference.md)
* [Language specification](/docs/LanguageSpecification.md)
* [GYP Hacking](/docs/Hacking.md)
* [GYP Testing](/docs/Testing.md)
* [GYP vs. CMake](/docs/GypVsCMake.md)
* [Source](/docs/Source.md)
* [Buildbot](/docs/Buildbot.md)
